import json
import os
import boto3
from datetime import datetime, timezone
from decimal import Decimal
from boto3.dynamodb.conditions import Key
from auth_utils import extract_user_from_event, get_user_display_name

# Initialize DynamoDB
dynamodb = boto3.resource('dynamodb')
table_name = os.environ['DYNAMODB_TABLE']
table = dynamodb.Table(table_name)

class DecimalEncoder(json.JSONEncoder):
    def default(self, obj):
        if isinstance(obj, Decimal):
            return float(obj)
        return super(DecimalEncoder, self).default(obj)

def lambda_handler(event, context):
    try:
        # Determine endpoint from path
        path = event.get('path', '').lower()
        http_method = event.get('httpMethod', 'GET')
        
        # Get query parameters
        query_params = event.get('queryStringParameters') or {}
        user_id = extract_user_from_event(event)
        start_date = query_params.get('startDate')
        end_date = query_params.get('endDate')
        status = query_params.get('status')  # 'active', 'completed', or None for all
        
        # Handle monthly hours endpoint
        if '/hours' in path:
            year = query_params.get('year')
            month = query_params.get('month')
            return handle_monthly_hours(user_id, year, month)
            
        # Handle regular entries endpoint
        return handle_entries(user_id, start_date, end_date, status)
        
    except Exception as e:
        print(f"Error: {str(e)}")
        return {
            'statusCode': 500,
            'headers': {
                'Access-Control-Allow-Origin': '*',
                'Access-Control-Allow-Headers': 'Content-Type,Authorization',
                'Access-Control-Allow-Methods': 'OPTIONS,POST,GET,PUT,DELETE'
            },
            'body': json.dumps({
                'error': 'Internal server error',
                'details': str(e)
            })
        }

def handle_entries(user_id, start_date, end_date, status):
    """Handle /entries endpoint"""
    try:
        # Build query
        key_condition = Key('PK').eq(f'USER#{user_id}')
        
        # Query DynamoDB
        if start_date or end_date:
            # Use GSI1 for date-based queries
            response = table.query(
                IndexName='GSI1',
                KeyConditionExpression=Key('GSI1PK').eq(f'USER#{user_id}')
            )
        else:
            response = table.query(
                KeyConditionExpression=key_condition
            )
        
        items = response['Items']
        
        # Filter by date range if specified
        if start_date or end_date:
            filtered_items = []
            for item in items:
                item_date = item.get('date')
                if item_date:
                    if start_date and item_date < start_date:
                        continue
                    if end_date and item_date > end_date:
                        continue
                filtered_items.append(item)
            items = filtered_items
        
        # Filter by status if specified
        if status:
            items = [item for item in items if item.get('status') == status]
        
        # Sort by creation date (most recent first)
        items.sort(key=lambda x: x.get('createdAt', ''), reverse=True)
        
        # Calculate current session time for active entries
        for item in items:
            if item.get('status') == 'active' and item.get('clockInTime'):
                clock_in = datetime.fromisoformat(item['clockInTime'].replace('Z', '+00:00'))
                current_time = datetime.now(timezone.utc)
                current_hours = (current_time - clock_in).total_seconds() / 3600
                item['currentHours'] = round(current_hours, 2)
        
        # Format response for frontend compatibility
        formatted_items = []
        for item in items:
            formatted_item = {
                'id': item.get('entryId'),  # Frontend expects 'id'
                'startTime': item.get('clockInTime'),  # Frontend expects 'startTime'
                'endTime': item.get('clockOutTime'),   # Frontend expects 'endTime'
                'duration': float(item['hoursWorked']) if item.get('hoursWorked') else (item.get('currentHours') or 0),
                'status': item.get('status'),
                'date': item.get('date'),
                'createdAt': item.get('createdAt'),
                'updatedAt': item.get('updatedAt')
            }
            formatted_items.append(formatted_item)
        
        # Return direct array for frontend compatibility
        return {
            'statusCode': 200,
            'headers': {
                'Access-Control-Allow-Origin': '*',
                'Access-Control-Allow-Headers': 'Content-Type,Authorization',
                'Access-Control-Allow-Methods': 'OPTIONS,POST,GET,PUT,DELETE'
            },
            'body': json.dumps(formatted_items, cls=DecimalEncoder)
        }
        
    except Exception as e:
        print(f"Error: {str(e)}")
        return {
            'statusCode': 500,
            'headers': {
                'Access-Control-Allow-Origin': '*',
                'Access-Control-Allow-Headers': 'Content-Type,Authorization',
                'Access-Control-Allow-Methods': 'OPTIONS,POST,GET,PUT,DELETE'
            },
            'body': json.dumps({
                'error': 'Internal server error',
                'details': str(e)
            })
        }

def handle_monthly_hours(user_id, year, month):
    """Handle /hours endpoint for monthly totals"""
    try:
        if not year or not month:
            current_date = datetime.now(timezone.utc)
            year = year or str(current_date.year)
            month = month or str(current_date.month)
            
        # Calculate month start and end dates
        year_int = int(year)
        month_int = int(month)
        month_start = datetime(year_int, month_int, 1, tzinfo=timezone.utc)
        
        if month_int == 12:
            month_end = datetime(year_int + 1, 1, 1, tzinfo=timezone.utc)
        else:
            month_end = datetime(year_int, month_int + 1, 1, tzinfo=timezone.utc)
        
        # Query DynamoDB for the user's entries
        response = table.query(
            KeyConditionExpression=Key('PK').eq(f'USER#{user_id}')
        )
        
        total_hours = 0
        for item in response['Items']:
            if item.get('date') and item.get('hoursWorked') and item.get('status') == 'completed':
                try:
                    item_date = datetime.fromisoformat(item['date'] + 'T00:00:00+00:00')
                    if month_start <= item_date < month_end:
                        total_hours += float(item['hoursWorked'])
                except:
                    continue
        
        return {
            'statusCode': 200,
            'headers': {
                'Access-Control-Allow-Origin': '*',
                'Access-Control-Allow-Headers': 'Content-Type,Authorization',
                'Access-Control-Allow-Methods': 'OPTIONS,POST,GET,PUT,DELETE'
            },
            'body': json.dumps({'totalHours': round(total_hours, 2)})
        }
        
    except Exception as e:
        print(f"Error in monthly hours: {str(e)}")
        return {
            'statusCode': 500,
            'headers': {
                'Access-Control-Allow-Origin': '*',
                'Access-Control-Allow-Headers': 'Content-Type,Authorization',
                'Access-Control-Allow-Methods': 'OPTIONS,POST,GET,PUT,DELETE'
            },
            'body': json.dumps({
                'error': 'Internal server error',
                'details': str(e)
            })
        }