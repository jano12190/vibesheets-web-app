"""
Authentication utilities for extracting user information from JWT tokens
"""
import json
import base64
from typing import Optional, Dict, Any

def extract_user_from_event(event: Dict[str, Any]) -> str:
    """
    Extract user ID from Lambda event (Auth0 JWT token or query parameters)
    
    Args:
        event: Lambda event object
        
    Returns:
        User ID string, defaults to 'default_user' if not found
    """
    # Method 1: Try to get from Authorization header (JWT token)
    user_id = extract_user_from_jwt(event)
    if user_id:
        return user_id
    
    # Method 2: Try to get from query parameters (for development/testing)
    query_params = event.get('queryStringParameters') or {}
    user_id = query_params.get('userId')
    if user_id:
        return user_id
    
    # Method 3: Try to get from request body (for development/testing)
    if event.get('body'):
        try:
            body = json.loads(event['body'])
            user_id = body.get('userId')
            if user_id:
                return user_id
        except:
            pass
    
    # Method 4: Default fallback
    return 'default_user'

def extract_user_from_jwt(event: Dict[str, Any]) -> Optional[str]:
    """
    Extract user ID from JWT token in Authorization header
    
    Args:
        event: Lambda event object
        
    Returns:
        User ID from JWT token, or None if not found/invalid
    """
    try:
        # Get Authorization header
        headers = event.get('headers') or {}
        auth_header = headers.get('Authorization') or headers.get('authorization')
        
        if not auth_header or not auth_header.startswith('Bearer '):
            return None
        
        # Extract JWT token
        token = auth_header.split(' ')[1]
        
        # Decode JWT payload (without verification for now - in production you should verify)
        # JWT structure: header.payload.signature
        parts = token.split('.')
        if len(parts) != 3:
            return None
        
        # Decode payload (base64url decode)
        payload_b64 = parts[1]
        # Add padding if needed for base64 decoding
        padding = 4 - (len(payload_b64) % 4)
        if padding != 4:
            payload_b64 += '=' * padding
        
        payload_json = base64.urlsafe_b64decode(payload_b64).decode('utf-8')
        payload = json.loads(payload_json)
        
        # Extract user ID from Auth0 token
        # Auth0 typically uses 'sub' (subject) field for user ID
        user_id = payload.get('sub')
        if user_id:
            # Auth0 user IDs often have format like "auth0|123456" or "google-oauth2|123456"
            # Extract just the unique part or use the full ID
            return user_id
        
        # Alternative fields to check
        user_id = payload.get('user_id') or payload.get('email') or payload.get('nickname')
        if user_id:
            return user_id
            
        return None
        
    except Exception as e:
        print(f"Error extracting user from JWT: {str(e)}")
        return None

def get_user_display_name(event: Dict[str, Any]) -> str:
    """
    Extract user display name from JWT token for logging/display purposes
    
    Args:
        event: Lambda event object
        
    Returns:
        User display name or fallback
    """
    try:
        headers = event.get('headers') or {}
        auth_header = headers.get('Authorization') or headers.get('authorization')
        
        if not auth_header or not auth_header.startswith('Bearer '):
            return 'Unknown User'
        
        token = auth_header.split(' ')[1]
        parts = token.split('.')
        if len(parts) != 3:
            return 'Unknown User'
        
        payload_b64 = parts[1]
        padding = 4 - (len(payload_b64) % 4)
        if padding != 4:
            payload_b64 += '=' * padding
        
        payload_json = base64.urlsafe_b64decode(payload_b64).decode('utf-8')
        payload = json.loads(payload_json)
        
        # Try various name fields
        name = (payload.get('name') or 
                payload.get('nickname') or 
                payload.get('email') or 
                payload.get('sub', 'Unknown User'))
        
        return name
        
    except Exception as e:
        print(f"Error extracting user display name: {str(e)}")
        return 'Unknown User'