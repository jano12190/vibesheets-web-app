import json
import os
import boto3
from datetime import datetime, timezone
from boto3.dynamodb.conditions import Key
from auth_utils import extract_user_from_event, get_user_display_name

# Initialize DynamoDB
dynamodb = boto3.resource('dynamodb')
table_name = os.environ['DYNAMODB_TABLE']
table = dynamodb.Table(table_name)

def lambda_handler(event, context):
    try:
        # Get user ID from authentication token
        user_id = extract_user_from_event(event)
        
        # Check for active clock-in session
        response = table.query(
            KeyConditionExpression=Key('PK').eq(f'USER#{user_id}'),
            FilterExpression='#status = :status',
            ExpressionAttributeNames={
                '#status': 'status'
            },
            ExpressionAttributeValues={
                ':status': 'active'
            }
        )
        
        clocked_in = False
        clock_in_time = None
        entry_id = None
        
        if response['Items']:
            # Get the most recent active entry
            active_entry = response['Items'][0]
            clocked_in = True
            clock_in_time = active_entry.get('clockInTime')
            entry_id = active_entry.get('entryId')
        
        return {
            'statusCode': 200,
            'headers': {
                'Access-Control-Allow-Origin': '*',
                'Access-Control-Allow-Headers': 'Content-Type,Authorization',
                'Access-Control-Allow-Methods': 'OPTIONS,POST,GET,PUT'
            },
            'body': json.dumps({
                'clockedIn': clocked_in,
                'clockInTime': clock_in_time,
                'entryId': entry_id
            })
        }
        
    except Exception as e:
        print(f"Error: {str(e)}")
        return {
            'statusCode': 500,
            'headers': {
                'Access-Control-Allow-Origin': '*',
                'Access-Control-Allow-Headers': 'Content-Type,Authorization',
                'Access-Control-Allow-Methods': 'OPTIONS,POST,GET,PUT'
            },
            'body': json.dumps({
                'error': 'Internal server error',
                'details': str(e)
            })
        }