import json
import os
import boto3
from datetime import datetime, timezone
from decimal import Decimal
from auth_utils import extract_user_from_event, get_user_display_name

# Initialize DynamoDB
dynamodb = boto3.resource('dynamodb')
table_name = os.environ['DYNAMODB_TABLE']
table = dynamodb.Table(table_name)

def lambda_handler(event, context):
    try:
        # Get entry ID from path parameters
        path_params = event.get('pathParameters') or {}
        entry_id = path_params.get('entryId')
        http_method = event.get('httpMethod', 'PUT')
        
        if not entry_id:
            return {
                'statusCode': 400,
                'headers': {
                    'Access-Control-Allow-Origin': '*',
                    'Access-Control-Allow-Headers': 'Content-Type,Authorization',
                    'Access-Control-Allow-Methods': 'OPTIONS,POST,GET,PUT,DELETE'
                },
                'body': json.dumps({
                    'error': 'Entry ID is required'
                })
            }
        
        # Handle DELETE requests
        if http_method == 'DELETE':
            return handle_delete_entry(entry_id, event)
        
        # Handle PUT requests (existing update functionality)
        
        # Parse request body
        if event.get('body'):
            body = json.loads(event['body'])
        else:
            return {
                'statusCode': 400,
                'headers': {
                    'Access-Control-Allow-Origin': '*',
                    'Access-Control-Allow-Headers': 'Content-Type,Authorization',
                    'Access-Control-Allow-Methods': 'OPTIONS,POST,GET,PUT,DELETE'
                },
                'body': json.dumps({
                    'error': 'Request body is required'
                })
            }
        
        user_id = extract_user_from_event(event)
        
        # First, get the existing entry to validate it exists
        try:
            response = table.get_item(
                Key={
                    'PK': f'USER#{user_id}',
                    'SK': f'ENTRY#{entry_id}'
                }
            )
            
            if 'Item' not in response:
                return {
                    'statusCode': 404,
                    'headers': {
                        'Access-Control-Allow-Origin': '*',
                        'Access-Control-Allow-Headers': 'Content-Type',
                        'Access-Control-Allow-Methods': 'OPTIONS,POST,GET,PUT'
                    },
                    'body': json.dumps({
                        'error': 'Timesheet entry not found'
                    })
                }
            
            existing_item = response['Item']
            
        except Exception as e:
            return {
                'statusCode': 500,
                'headers': {
                    'Access-Control-Allow-Origin': '*',
                    'Access-Control-Allow-Headers': 'Content-Type,Authorization',
                    'Access-Control-Allow-Methods': 'OPTIONS,POST,GET,PUT,DELETE'
                },
                'body': json.dumps({
                    'error': 'Failed to retrieve existing entry',
                    'details': str(e)
                })
            }
        
        # Build update expression
        update_expression = "SET updatedAt = :updated"
        expression_values = {
            ':updated': datetime.now(timezone.utc).isoformat()
        }
        expression_names = {}
        
        # Handle updatable fields
        if 'clockInTime' in body:
            update_expression += ", clockInTime = :clock_in"
            expression_values[':clock_in'] = body['clockInTime']
        
        if 'clockOutTime' in body:
            update_expression += ", clockOutTime = :clock_out"
            expression_values[':clock_out'] = body['clockOutTime']
        
        if 'date' in body:
            update_expression += ", #date = :date"
            expression_values[':date'] = body['date']
            expression_names['#date'] = 'date'
        
        if 'status' in body:
            update_expression += ", #status = :status"
            expression_values[':status'] = body['status']
            expression_names['#status'] = 'status'
        
        # Recalculate hours if both clock in and out times are provided
        clock_in_time = body.get('clockInTime', existing_item.get('clockInTime'))
        clock_out_time = body.get('clockOutTime', existing_item.get('clockOutTime'))
        
        if clock_in_time and clock_out_time:
            try:
                # Parse times and calculate hours
                clock_in = datetime.fromisoformat(clock_in_time.replace('Z', '+00:00'))
                clock_out = datetime.fromisoformat(clock_out_time.replace('Z', '+00:00'))
                
                if clock_out > clock_in:
                    hours_worked = (clock_out - clock_in).total_seconds() / 3600
                    update_expression += ", hoursWorked = :hours"
                    expression_values[':hours'] = Decimal(str(round(hours_worked, 2)))
                else:
                    return {
                        'statusCode': 400,
                        'headers': {
                            'Access-Control-Allow-Origin': '*',
                            'Access-Control-Allow-Headers': 'Content-Type',
                            'Access-Control-Allow-Methods': 'OPTIONS,POST,GET,PUT'
                        },
                        'body': json.dumps({
                            'error': 'Clock out time must be after clock in time'
                        })
                    }
            except ValueError as e:
                return {
                    'statusCode': 400,
                    'headers': {
                        'Access-Control-Allow-Origin': '*',
                        'Access-Control-Allow-Headers': 'Content-Type',
                        'Access-Control-Allow-Methods': 'OPTIONS,POST,GET,PUT'
                    },
                    'body': json.dumps({
                        'error': 'Invalid datetime format',
                        'details': str(e)
                    })
                }
        
        # Update the item
        update_params = {
            'Key': {
                'PK': f'USER#{user_id}',
                'SK': f'ENTRY#{entry_id}'
            },
            'UpdateExpression': update_expression,
            'ExpressionAttributeValues': expression_values,
            'ReturnValues': 'ALL_NEW'
        }
        
        if expression_names:
            update_params['ExpressionAttributeNames'] = expression_names
        
        response = table.update_item(**update_params)
        
        # Format response
        updated_item = response['Attributes']
        formatted_item = {
            'entryId': updated_item.get('entryId'),
            'userId': updated_item.get('userId'),
            'date': updated_item.get('date'),
            'clockInTime': updated_item.get('clockInTime'),
            'clockOutTime': updated_item.get('clockOutTime'),
            'hoursWorked': float(updated_item['hoursWorked']) if updated_item.get('hoursWorked') else None,
            'status': updated_item.get('status'),
            'createdAt': updated_item.get('createdAt'),
            'updatedAt': updated_item.get('updatedAt')
        }
        
        return {
            'statusCode': 200,
            'headers': {
                'Access-Control-Allow-Origin': '*',
                'Access-Control-Allow-Headers': 'Content-Type',
                'Access-Control-Allow-Methods': 'OPTIONS,POST,GET,PUT'
            },
            'body': json.dumps({
                'message': 'Timesheet entry updated successfully',
                'entry': formatted_item
            })
        }
        
    except Exception as e:
        print(f"Error: {str(e)}")
        return {
            'statusCode': 500,
            'headers': {
                'Access-Control-Allow-Origin': '*',
                'Access-Control-Allow-Headers': 'Content-Type',
                'Access-Control-Allow-Methods': 'OPTIONS,POST,GET,PUT'
            },
            'body': json.dumps({
                'error': 'Internal server error',
                'details': str(e)
            })
        }

def handle_delete_entry(entry_id, event):
    """Handle DELETE requests for time entries"""
    try:
        # Get user_id from authentication token
        user_id = extract_user_from_event(event)
        
        # First check if the entry exists
        try:
            response = table.get_item(
                Key={
                    'PK': f'USER#{user_id}',
                    'SK': f'ENTRY#{entry_id}'
                }
            )
            
            if 'Item' not in response:
                return {
                    'statusCode': 404,
                    'headers': {
                        'Access-Control-Allow-Origin': '*',
                        'Access-Control-Allow-Headers': 'Content-Type,Authorization',
                        'Access-Control-Allow-Methods': 'OPTIONS,POST,GET,PUT,DELETE'
                    },
                    'body': json.dumps({
                        'error': 'Timesheet entry not found'
                    })
                }
        except Exception as e:
            return {
                'statusCode': 500,
                'headers': {
                    'Access-Control-Allow-Origin': '*',
                    'Access-Control-Allow-Headers': 'Content-Type,Authorization',
                    'Access-Control-Allow-Methods': 'OPTIONS,POST,GET,PUT,DELETE'
                },
                'body': json.dumps({
                    'error': 'Failed to check entry existence',
                    'details': str(e)
                })
            }
        
        # Delete the entry
        table.delete_item(
            Key={
                'PK': f'USER#{user_id}',
                'SK': f'ENTRY#{entry_id}'
            }
        )
        
        return {
            'statusCode': 200,
            'headers': {
                'Access-Control-Allow-Origin': '*',
                'Access-Control-Allow-Headers': 'Content-Type,Authorization',
                'Access-Control-Allow-Methods': 'OPTIONS,POST,GET,PUT,DELETE'
            },
            'body': json.dumps({
                'message': 'Timesheet entry deleted successfully',
                'entryId': entry_id
            })
        }
        
    except Exception as e:
        print(f"Delete error: {str(e)}")
        return {
            'statusCode': 500,
            'headers': {
                'Access-Control-Allow-Origin': '*',
                'Access-Control-Allow-Headers': 'Content-Type,Authorization',
                'Access-Control-Allow-Methods': 'OPTIONS,POST,GET,PUT,DELETE'
            },
            'body': json.dumps({
                'error': 'Failed to delete timesheet entry',
                'details': str(e)
            })
        }