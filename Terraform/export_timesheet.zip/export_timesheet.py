import json
import os
import boto3
from datetime import datetime, timezone
from decimal import Decimal
from boto3.dynamodb.conditions import Key
import base64
from io import BytesIO
import csv
from auth_utils import extract_user_from_event, get_user_display_name

# Initialize DynamoDB
dynamodb = boto3.resource('dynamodb')
table_name = os.environ['DYNAMODB_TABLE']
table = dynamodb.Table(table_name)

def lambda_handler(event, context):
    try:
        # Get query parameters
        query_params = event.get('queryStringParameters') or {}
        user_id = extract_user_from_event(event)
        start_date = query_params.get('startDate')
        end_date = query_params.get('endDate')
        export_format = query_params.get('format', 'csv').lower()  # csv or json
        
        # Validate export format
        if export_format not in ['csv', 'json']:
            return {
                'statusCode': 400,
                'headers': {
                    'Access-Control-Allow-Origin': '*',
                    'Access-Control-Allow-Headers': 'Content-Type,Authorization',
                    'Access-Control-Allow-Methods': 'OPTIONS,POST,GET,PUT,DELETE'
                },
                'body': json.dumps({
                    'error': 'Invalid format. Supported formats: csv, json'
                })
            }
        
        # Query DynamoDB for timesheet entries
        if start_date or end_date:
            # Use GSI1 for date-based queries
            response = table.query(
                IndexName='GSI1',
                KeyConditionExpression=Key('GSI1PK').eq(f'USER#{user_id}')
            )
        else:
            response = table.query(
                KeyConditionExpression=Key('PK').eq(f'USER#{user_id}')
            )
        
        items = response['Items']
        
        # Filter by date range if specified
        if start_date or end_date:
            filtered_items = []
            for item in items:
                item_date = item.get('date')
                if item_date:
                    if start_date and item_date < start_date:
                        continue
                    if end_date and item_date > end_date:
                        continue
                filtered_items.append(item)
            items = filtered_items
        
        # Only include completed entries for export
        completed_items = [item for item in items if item.get('status') == 'completed']
        
        # Sort by date
        completed_items.sort(key=lambda x: x.get('date', ''))
        
        if not completed_items:
            return {
                'statusCode': 200,
                'headers': {
                    'Access-Control-Allow-Origin': '*',
                    'Access-Control-Allow-Headers': 'Content-Type,Authorization',
                    'Access-Control-Allow-Methods': 'OPTIONS,POST,GET,PUT,DELETE'
                },
                'body': json.dumps({
                    'message': 'No completed timesheet entries found for the specified period',
                    'count': 0
                })
            }
        
        # Prepare data for export
        export_data = []
        total_hours = 0
        
        for item in completed_items:
            # Convert DynamoDB item to export format
            export_entry = {
                'Entry ID': item.get('entryId', ''),
                'Date': item.get('date', ''),
                'Clock In Time': format_datetime(item.get('clockInTime')),
                'Clock Out Time': format_datetime(item.get('clockOutTime')),
                'Hours Worked': float(item['hoursWorked']) if item.get('hoursWorked') else 0,
                'Status': item.get('status', ''),
                'Created At': format_datetime(item.get('createdAt')),
                'Updated At': format_datetime(item.get('updatedAt'))
            }
            export_data.append(export_entry)
            total_hours += export_entry['Hours Worked']
        
        # Generate export based on format
        if export_format == 'csv':
            return generate_csv_export(export_data, total_hours, start_date, end_date)
        else:  # json
            return generate_json_export(export_data, total_hours, start_date, end_date)
            
    except Exception as e:
        print(f"Error: {str(e)}")
        return {
            'statusCode': 500,
            'headers': {
                'Access-Control-Allow-Origin': '*',
                'Access-Control-Allow-Headers': 'Content-Type',
                'Access-Control-Allow-Methods': 'OPTIONS,POST,GET,PUT'
            },
            'body': json.dumps({
                'error': 'Internal server error',
                'details': str(e)
            })
        }

def format_datetime(dt_string):
    """Format datetime string for better readability"""
    if not dt_string:
        return ''
    try:
        dt = datetime.fromisoformat(dt_string.replace('Z', '+00:00'))
        return dt.strftime('%Y-%m-%d %H:%M:%S UTC')
    except:
        return dt_string

def generate_csv_export(data, total_hours, start_date, end_date):
    """Generate CSV export"""
    try:
        # Create CSV content
        output = BytesIO()
        
        # Write CSV header with metadata
        csv_content = []
        csv_content.append(['Vibesheets Timesheet Export'])
        csv_content.append(['Generated At:', datetime.now(timezone.utc).strftime('%Y-%m-%d %H:%M:%S UTC')])
        
        if start_date:
            csv_content.append(['Start Date:', start_date])
        if end_date:
            csv_content.append(['End Date:', end_date])
            
        csv_content.append(['Total Hours:', f'{total_hours:.2f}'])
        csv_content.append(['Total Entries:', str(len(data))])
        csv_content.append([])  # Empty row
        
        # Write data headers
        if data:
            headers = list(data[0].keys())
            csv_content.append(headers)
            
            # Write data rows
            for row in data:
                csv_content.append([str(row[header]) for header in headers])
        
        # Convert to string
        csv_string = ''
        for row in csv_content:
            csv_string += ','.join(f'"{str(cell)}"' for cell in row) + '\n'
        
        # Encode to base64 for binary response
        csv_bytes = csv_string.encode('utf-8')
        csv_base64 = base64.b64encode(csv_bytes).decode('utf-8')
        
        # Generate filename
        date_suffix = f"_{start_date}_to_{end_date}" if start_date and end_date else f"_{datetime.now(timezone.utc).strftime('%Y%m%d')}"
        filename = f"vibesheets_timesheet{date_suffix}.csv"
        
        return {
            'statusCode': 200,
            'headers': {
                'Access-Control-Allow-Origin': '*',
                'Access-Control-Allow-Headers': 'Content-Type',
                'Access-Control-Allow-Methods': 'OPTIONS,POST,GET,PUT',
                'Content-Type': 'text/csv',
                'Content-Disposition': f'attachment; filename="{filename}"'
            },
            'body': csv_base64,
            'isBase64Encoded': True
        }
        
    except Exception as e:
        raise Exception(f"CSV generation failed: {str(e)}")

def generate_json_export(data, total_hours, start_date, end_date):
    """Generate JSON export"""
    try:
        export_summary = {
            'export_info': {
                'generated_at': datetime.now(timezone.utc).isoformat(),
                'format': 'json',
                'start_date': start_date,
                'end_date': end_date,
                'total_entries': len(data),
                'total_hours': round(total_hours, 2)
            },
            'timesheet_entries': data
        }
        
        # Generate filename
        date_suffix = f"_{start_date}_to_{end_date}" if start_date and end_date else f"_{datetime.now(timezone.utc).strftime('%Y%m%d')}"
        filename = f"vibesheets_timesheet{date_suffix}.json"
        
        # Convert to base64 for binary response
        json_string = json.dumps(export_summary, indent=2)
        json_bytes = json_string.encode('utf-8')
        json_base64 = base64.b64encode(json_bytes).decode('utf-8')
        
        return {
            'statusCode': 200,
            'headers': {
                'Access-Control-Allow-Origin': '*',
                'Access-Control-Allow-Headers': 'Content-Type',
                'Access-Control-Allow-Methods': 'OPTIONS,POST,GET,PUT',
                'Content-Type': 'application/json',
                'Content-Disposition': f'attachment; filename="{filename}"'
            },
            'body': json_base64,
            'isBase64Encoded': True
        }
        
    except Exception as e:
        raise Exception(f"JSON generation failed: {str(e)}")