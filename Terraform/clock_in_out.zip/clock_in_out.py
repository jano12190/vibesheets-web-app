import json
import os
import boto3
from datetime import datetime, timezone
import uuid
from decimal import Decimal
from auth_utils import extract_user_from_event, get_user_display_name

# Initialize DynamoDB
dynamodb = boto3.resource('dynamodb')
table_name = os.environ['DYNAMODB_TABLE']
table = dynamodb.Table(table_name)

def lambda_handler(event, context):
    try:
        # Determine action from HTTP method and path
        http_method = event.get('httpMethod', 'POST')
        path = event.get('path', '').lower()
        
        # Parse request body
        if event.get('body'):
            body = json.loads(event['body'])
        else:
            body = {}
        
        # Determine action from path
        if '/clock-in' in path:
            action = 'clock_in'
        elif '/clock-out' in path:
            action = 'clock_out'
        else:
            # Fallback to body parameter for backward compatibility
            action = body.get('action')
        
        # Get user ID from authentication token
        user_id = extract_user_from_event(event)
        user_name = get_user_display_name(event)
        
        # Frontend sends timestamp, we can use it or generate our own
        timestamp = body.get('timestamp')
        if timestamp:
            current_time = datetime.fromisoformat(timestamp.replace('Z', '+00:00'))
        else:
            current_time = datetime.now(timezone.utc)
        
        if not action or action not in ['clock_in', 'clock_out']:
            return {
                'statusCode': 400,
                'headers': {
                    'Access-Control-Allow-Origin': '*',
                    'Access-Control-Allow-Headers': 'Content-Type,Authorization',
                    'Access-Control-Allow-Methods': 'OPTIONS,POST,GET,PUT,DELETE'
                },
                'body': json.dumps({
                    'error': 'Invalid action. Must be clock_in or clock_out'
                })
            }
        
        print(f"User {user_name} ({user_id}) attempting to {action}")
        
        if action == 'clock_in':
            # Create new time entry
            entry_id = str(uuid.uuid4())
            
            item = {
                'PK': f'USER#{user_id}',
                'SK': f'ENTRY#{entry_id}',
                'GSI1PK': f'USER#{user_id}',
                'GSI1SK': current_time.isoformat(),
                'entryId': entry_id,
                'userId': user_id,
                'clockInTime': current_time.isoformat(),
                'date': current_time.strftime('%Y-%m-%d'),
                'status': 'active',
                'createdAt': current_time.isoformat(),
                'updatedAt': current_time.isoformat()
            }
            
            table.put_item(Item=item)
            
            return {
                'statusCode': 200,
                'headers': {
                    'Access-Control-Allow-Origin': '*',
                    'Access-Control-Allow-Headers': 'Content-Type,Authorization',
                    'Access-Control-Allow-Methods': 'OPTIONS,POST,GET,PUT,DELETE'
                },
                'body': json.dumps({
                    'message': 'Clocked in successfully',
                    'entryId': entry_id,
                    'clockInTime': current_time.isoformat(),
                    'status': 'active'
                })
            }
            
        elif action == 'clock_out':
            # Find active entry and clock out
            response = table.query(
                KeyConditionExpression='PK = :pk',
                FilterExpression='#status = :status',
                ExpressionAttributeNames={
                    '#status': 'status'
                },
                ExpressionAttributeValues={
                    ':pk': f'USER#{user_id}',
                    ':status': 'active'
                }
            )
            
            if not response['Items']:
                return {
                    'statusCode': 400,
                    'headers': {
                        'Access-Control-Allow-Origin': '*',
                        'Access-Control-Allow-Headers': 'Content-Type',
                        'Access-Control-Allow-Methods': 'OPTIONS,POST,GET,PUT'
                    },
                    'body': json.dumps({
                        'error': 'No active clock-in session found'
                    })
                }
            
            # Get the most recent active entry
            active_entry = response['Items'][0]
            entry_id = active_entry['entryId']
            clock_in_time = datetime.fromisoformat(active_entry['clockInTime'].replace('Z', '+00:00'))
            
            # Calculate hours worked
            hours_worked = (current_time - clock_in_time).total_seconds() / 3600
            
            # Update the entry
            table.update_item(
                Key={
                    'PK': f'USER#{user_id}',
                    'SK': f'ENTRY#{entry_id}'
                },
                UpdateExpression='SET clockOutTime = :out_time, hoursWorked = :hours, #status = :status, updatedAt = :updated',
                ExpressionAttributeNames={
                    '#status': 'status'
                },
                ExpressionAttributeValues={
                    ':out_time': current_time.isoformat(),
                    ':hours': Decimal(str(round(hours_worked, 2))),
                    ':status': 'completed',
                    ':updated': current_time.isoformat()
                }
            )
            
            return {
                'statusCode': 200,
                'headers': {
                    'Access-Control-Allow-Origin': '*',
                    'Access-Control-Allow-Headers': 'Content-Type,Authorization',
                    'Access-Control-Allow-Methods': 'OPTIONS,POST,GET,PUT,DELETE'
                },
                'body': json.dumps({
                    'message': 'Clocked out successfully',
                    'entryId': entry_id,
                    'clockOutTime': current_time.isoformat(),
                    'hoursWorked': round(hours_worked, 2),
                    'status': 'completed'
                })
            }
            
    except Exception as e:
        print(f"Error: {str(e)}")
        return {
            'statusCode': 500,
            'headers': {
                'Access-Control-Allow-Origin': '*',
                'Access-Control-Allow-Headers': 'Content-Type',
                'Access-Control-Allow-Methods': 'OPTIONS,POST,GET,PUT'
            },
            'body': json.dumps({
                'error': 'Internal server error',
                'details': str(e)
            })
        }