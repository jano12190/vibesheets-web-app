import json
import boto3
from botocore.exceptions import ClientError
import os

def lambda_handler(event, context):
    # Get allowed origins from environment variable
    allowed_origins = os.environ.get('ALLOWED_ORIGINS', '').split(',')
    origin = event.get('headers', {}).get('Origin') or event.get('headers', {}).get('origin')
    
    # Determine CORS origin
    cors_origin = '*'
    if origin and origin in allowed_origins:
        cors_origin = origin
    
    # CORS headers
    headers = {
        'Access-Control-Allow-Origin': cors_origin,
        'Access-Control-Allow-Headers': 'Content-Type,Authorization',
        'Access-Control-Allow-Methods': 'GET,OPTIONS',
        'Content-Type': 'application/json'
    }
    
    # Handle preflight OPTIONS request
    if event.get('httpMethod') == 'OPTIONS':
        return {
            'statusCode': 200,
            'headers': headers,
            'body': ''
        }
    
    try:
        # Get region from environment or default to us-east-1
        region = os.environ.get('AWS_REGION', 'us-east-1')
        secrets_client = boto3.client('secretsmanager', region_name=region)
        
        # Get Auth0 credentials
        auth0_response = secrets_client.get_secret_value(
            SecretId='vibesheets/auth0-credentials'
        )
        auth0_data = json.loads(auth0_response['SecretString'])
        
        # Get OAuth credentials
        oauth_response = secrets_client.get_secret_value(
            SecretId='vibesheets/oauth-credentials'
        )
        oauth_data = json.loads(oauth_response['SecretString'])
        
        # Prepare configuration response
        config = {
            'auth0_domain': auth0_data.get('auth0_domain'),
            'auth0_client_id': auth0_data.get('auth0_client_id'),
            'auth0_audience': auth0_data.get('auth0_audience'),
            'google_client_id': oauth_data.get('google_client_id')
        }
        
        # Validate that we have the required configuration
        missing_fields = [key for key, value in config.items() if not value or value.startswith('placeholder')]
        if missing_fields:
            return {
                'statusCode': 500,
                'headers': headers,
                'body': json.dumps({
                    'error': 'Configuration incomplete',
                    'missing_fields': missing_fields
                })
            }
        
        return {
            'statusCode': 200,
            'headers': headers,
            'body': json.dumps(config)
        }
        
    except ClientError as e:
        error_code = e.response['Error']['Code']
        if error_code == 'ResourceNotFoundException':
            error_msg = 'Authentication secrets not found. Please configure Auth0 and OAuth credentials in AWS Secrets Manager.'
        else:
            error_msg = f'AWS error: {error_code}'
        
        print(f"ClientError: {str(e)}")
        return {
            'statusCode': 500,
            'headers': headers,
            'body': json.dumps({'error': error_msg})
        }
        
    except Exception as e:
        print(f"Unexpected error: {str(e)}")
        return {
            'statusCode': 500,
            'headers': headers,
            'body': json.dumps({'error': 'Internal server error'})
        }
